//create mutation observer to handle changes to dom
var target = document.querySelector('body');
var observer = new MutationObserver(
	function(mutations) {
		mutations.forEach(function(mutation) {
			observer.disconnect();
			
			
			
			$('#main').attr('style', 'background-color: #0D0D0D');
			
			//search bar section
			$('#gbq1').attr('style', 'background-color: black'); //google logo
			$('#gb > div.gb_Jb.gb_Hc > div.gb_f.gb_pb').attr('style', 'background-color: black');
			$('#gba').attr('style', 'background-color: black');
			$('#gb > div.gb_Jb.gb_Hc > div.gb_Z.gb_Hc.gb_f.gb_Fc').attr('style', 'background-color: black');
			$('.gb_Ib').attr('style', 'background-color: black');
			$('#gb > div.gb_Lb.gb_Ic > div.gb_Z.gb_Ic.gb_f.gb_Hc').attr('style', 'background-color: black');
			$('#gb > div.gb_Lb.gb_Ic > div.gb_f.gb_rb').attr('style', 'background-color: black');
			
			//sets the background color for the search results
			$('#cnt').attr('style', 'background-color: #222');
			
			//sets the color for the strip above the search results
			$('#hdtbSum').attr('style', 'background-color: black');	
			$('#topabar').attr('style', 'background-color: #0D0D0D');

			$('.r a').attr('style', 'color: #6783ab');	//title of each result
			$('.fl').attr('style', 'color: #6783ab');	//shortcut links under each result
			
			//for the personal block list from google (that I modified).  
			//You won't find it on the store.
			$('div.blockLink > a').attr('style', 'color: #6783ab'); 
			
			//this handles links to files instead of html pages
			//it sets the color for when there is '[doc]' or '[pdf]' preceding the result title
			$('.w').attr('style', 'color: #6783ab');			
			
			//links at bottom of page that match searh term
			$('#brs > div._r > div > p > a').attr('style', 'color: #6783ab; font-weight:900;');	
			$('#brs > div._r > div > p > a > b').attr('style', 'color: #6783ab; font-weight:100;');
			
			$('#pnnext > span:nth-child(2)').attr('style', 'color: #6783ab; display: block; margin-left: 53px'); //next button in footer
			$('#pnprev > span:nth-child(2)').attr('style', 'color: #6783ab; display: block; margin-right: 35px; clear: right'); //previous button in footer

			
			//small change to handle the news tab
			$('div._fC._r > a').attr('style', 'color: #6783ab');
			$('div > div > a').attr('style', 'color: #6783ab');
			$('.news-author').attr('style', 'color: #6783ab');	
			
			//in the footer area, searches related to...
			$('#brs > div.card-section > div > p > a').attr('style', 'color: #6783ab');
			
			//page footer
			$('#fbar').attr('style', 'background-color: black');

			//fixes text in the View Profile button
			$('a[href^="https://plus.google.com/u/0/me"]').attr('style', 'color: white;');
			
			//this styles the definitions provided by google directly in the search results
			$('div._Hs').attr('style', 'color: #aaa;');
			$('div._YD').attr('style', 'color: #aaa;');
			
			$('#rcnt').attr('style', 'background-color: #222');
			$('#topabar').attr('style', 'background-color: #222');
			
			//modifies the options button
			$('a[href^="http://www.google.com/intl/en/options/"]').attr('style', 'background-color: #780000; border-radius: 3px; opacity: 100;');
			$('a[href^="http://www.google.com/intl/en/options/"]').hover(function(){
				$(this).attr('style', 'background-color: red; border-radius: 3px; opacity: 100;');
			}, function(){
				$(this).attr('style', 'background-color: #780000; border-radius: 3px; opacity: 100;');
			}); 
			
 			//modifies the notifications button
			$('a[href^="https://plus.google.com/u/0/notifications/all?hl=en"]').attr('style', 'background-color: #780000; width: 25px; border-radius: 3px;');
			$('a[href^="https://plus.google.com/u/0/notifications/all?hl=en"]').hover(function(){
				$(this).attr('style', 'background-color: red; border-radius: 3px; opacity: 100; width: 25px;');
			}, function(){
				$(this).attr('style', 'background-color: #780000; border-radius: 3px; opacity: 100; width: 25px;');
			});
			
			//for sidebar menus like for instance movie times
			$('#rhs_block > ol > li > div.kp-blk._C6._sx._UR').attr('style', 'background-color: rgb(121, 121, 121);');
			$('#rhs_block > ol:nth-child(2) > li > div.kp-blk._Ge._sx._UR').attr('style', 'background-color: rgb(121, 121, 121);');
			$('#rhs_block > ol:nth-child(2) > li > div.kp-blk._Ge._sx._UR').find('a').each(function(){
				$(this).attr('style', 'color: default;');
			});
			$('#newsbox').attr('style', 'background-color: #808080;');
			$('#newsbox').find('a').each(function(){
				$(this).attr('style', 'color: default;');
			});
			
			//handles the current page number
			$('.cur').attr('style', 'color: #808080;');
			
			observer.observe(target, config);
			}
		);    
	}
);
 
// configuration of the observer:
var config = { attributes: true, childList: true, characterData: true };
 
// pass in the target node, as well as the observer options
observer.observe(target, config);














