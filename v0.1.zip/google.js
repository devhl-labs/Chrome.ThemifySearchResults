//create mutation observer to handle changes to dom
var target = document.querySelector('body');
var observer = new MutationObserver(
	function(mutations) {
		mutations.forEach(function(mutation) {
			observer.disconnect();

			$('#main').attr('style', 'background-color: #0D0D0D');
			$('#hdtbSum').attr('style', 'background-color: #0D0D0D');	//section above results
			$('#topabar').attr('style', 'background-color: #0D0D0D');	//section above results

			$('.r a').attr('style', 'color: #6783ab !important');	//title of each result
			$('.fl').attr('style', 'color: #6783ab');	//shortcut links under each result
			
			//for the personal block list from google (that I modified).  
			//You won't find it on the store.
			$('div.blockLink > a > span').attr('style', 'color: #6783ab'); 
			
			$('#brs > div._r > div > p > a').attr('style', 'color: #6783ab; font-weight:900;');	//links at bottom of page that match searh term
			$('#brs > div._r > div > p > a > b').attr('style', 'color: #6783ab; font-weight:100;');	//links at bottom of page that match searh term
			$('#pnnext > span:nth-child(2)').attr('style', 'color: #6783ab; display: block; margin-left: 53px'); //next button in footer
			$('#pnprev > span:nth-child(2)').attr('style', 'color: #6783ab; display: block; margin-right: 35px; clear: right'); //previous button in footer

			
			//this section handles news
			$('div._fC._r > a').attr('style', 'color: #6783ab');
			$('div > div > a').attr('style', 'color: #6783ab');

			observer.observe(target, config);
			}
		);    
	}
);
 
// configuration of the observer:
var config = { attributes: true, childList: true, characterData: true };
 
// pass in the target node, as well as the observer options
observer.observe(target, config);














